
import React, { useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function Home() {
  const [courses, setCourses] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    fetch('https://eduquest-backend-api.zhorton888.repl.co/api/courses')
      .then(res => res.json())
      .then(setCourses);
    fetch('https://eduquest-backend-api.zhorton888.repl.co/api/jobs')
      .then(res => res.json())
      .then(setJobs);
  }, []);

  const filteredCourses = courses.filter(c => c.title.toLowerCase().includes(query.toLowerCase()));
  const filteredJobs = jobs.filter(j => j.title.toLowerCase().includes(query.toLowerCase()));

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-orange-100 p-4 text-center">
      <h1 className="text-4xl font-bold text-blue-900 mb-4">EduQuest</h1>
      <p className="text-orange-700 text-lg mb-6">No Debt. Real Skills. Get Hired.</p>

      <Input
        placeholder="Search courses or jobs..."
        value={query}
        onChange={e => setQuery(e.target.value)}
        className="mb-6 max-w-md mx-auto"
      />

      <div className="grid md:grid-cols-2 gap-6">
        <section>
          <h2 className="text-2xl text-blue-800 mb-2">Courses</h2>
          {filteredCourses.length ? (
            filteredCourses.map(course => (
              <Card key={course.id} className="mb-3 bg-white border border-blue-200">
                <CardContent className="text-left p-4">
                  <h3 className="font-semibold text-blue-800">{course.title}</h3>
                  <p className="text-sm text-gray-700">{course.description}</p>
                </CardContent>
              </Card>
            ))
          ) : (
            <p className="text-sm text-gray-600">No courses found.</p>
          )}
        </section>

        <section>
          <h2 className="text-2xl text-orange-800 mb-2">Jobs</h2>
          {filteredJobs.length ? (
            filteredJobs.map(job => (
              <Card key={job.id} className="mb-3 bg-white border border-orange-200">
                <CardContent className="text-left p-4">
                  <h3 className="font-semibold text-orange-800">{job.title}</h3>
                  <p className="text-sm text-gray-700">{job.company}</p>
                </CardContent>
              </Card>
            ))
          ) : (
            <p className="text-sm text-gray-600">No jobs found.</p>
          )}
        </section>
      </div>

      <div className="mt-10">
        <Button className="bg-orange-500 hover:bg-orange-600 text-white">Upload Resume</Button>
      </div>
    </main>
  );
}
